console.log('\u001b[35m\u001b[1m','Love Swiper? Support Vladimir\'s work by donating or pledging on patreon:');
console.log('\u001b[22m\u001b[39m\u001b[32m','> On Patreon https://patreon.com/vladimirkharlampidi');
console.log('\u001b[22m\u001b[39m\u001b[32m','> On Open Collective https://opencollective.com/swiper');
